export const addBackgroundImage = ($element, imagePath) =>
  $element.style = `background-image:url(${imagePath})`
