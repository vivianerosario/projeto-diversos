import { themeColor as color } from "./../profile.json";

export const black = '#262626'
export const themeColor =  color ||'#e60052'; // Otherwise pink
export const gray = '#c0c0c0'
export const grayLight = '#c0c0c0'
