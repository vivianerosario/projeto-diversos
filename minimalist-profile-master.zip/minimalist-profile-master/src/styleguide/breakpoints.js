export const mobileScreenSize = '500px'
export const contentWrapperTop = '100px'
export const headerHeight = 'var(--header-height)'
